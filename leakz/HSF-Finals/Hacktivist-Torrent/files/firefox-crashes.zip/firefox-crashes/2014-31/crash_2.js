function Check(cond, msg) {
  if (!cond) {
    Log('[-] ' + msg);
    throw msg;
  }
}

function LogMsgToServer(msg) {
  var xhr = XMLHttpRequest();
  xhr.open('POST', '/log', false); // synchronous
  xhr.setRequestHeader('Content-Type', 'binary/octet-stream');
  xhr.send(msg);
}

function LogMsgToHTML(msg) {
  var p = document.getElementById('log');
  p.innerHTML += msg + '<br/>';
}

function Log(msg) {
  console.log(msg);
  LogMsgToHTML(msg);
  LogMsgToServer(msg);
}

function Stop() {
  Check(0, 'STOP');
}

function CheckDefined(obj, field) {
  Check(typeof obj[field] !== 'undefined', 'Missing ' + field);
}

function AlignDown(value, alignment) {
  return value - value % alignment;
}

function AlignUp(value, alignment) {
  return value + ((alignment - (value % alignment)) % alignment);
}

function S32ToU32(value) {
  var buf = new ArrayBuffer(4);
  var unsigned_view = new Uint32Array(buf);
  var signed_view = new Int32Array(buf);
  signed_view[0] = value;
  return unsigned_view[0];
}

function U32Shl(value, bits) {
  if (bits >= 32)
    return 0;
  return S32ToU32(value << bits);
}

function U32Shr(value, bits) {
  if (bits >= 32)
    return 0;
  return S32ToU32(value >> bits);
}

function U32ToString(u32) {
  var str = u32.toString(16);
  return (new Array(8 - str.length + 1).join('0')) + str;
}

// <convert between javascript numbers>
function Num(high_u32, low_u32) {
  if (low_u32 === undefined) {
    low_u32 = high_u32;
    high_u32 = 0;
  }
  if (!(this instanceof Num))
    return new Num(high_u32, low_u32);
  this.value = new Uint32Array([low_u32, high_u32]);
}

Num.prototype.Low = function() {
  return this.value[0];
}

Num.prototype.High = function() {
  return this.value[1];
}

Num.prototype.SetLow = function(low) {
  this.value[0] = low;
}

Num.prototype.SetHigh = function(high) {
  this.value[1] = high;
}

Num.prototype.JsNum = function() {
  return this.value[0];
}
// </convert between javascript numbers>

Num.prototype.Copy = function() {
  return new Num(this.High(), this.Low());
}

Num.prototype.Assign = function(num) {
  this.SetHigh(num.High());
  this.SetLow(num.Low());
}

Num.prototype.Add = function(num) {
  this.Assign(this.Plus(num));
}

Num.prototype.Sub = function(num) {
  this.Assign(this.Minus(num));
}

Num.prototype.Plus = function(num) {
  var result = this.Copy();
  result.value[0] += num.Low();
  result.value[1] += num.High();
  if (result.value[0] < this.value[0])
    result.value[1]++;
  return result;
}

Num.prototype.Minus = function(num) {
  var result = this.Copy();
  result.value[0] -= num.Low();
  result.value[1] -= num.High();
  if (result.value[0] > this.value[0])
    result.value[1]--;
  return result;
}

Num.prototype.Shl = function(bits) {
  var low = this.value[0];
  var high = this.value[1];
  var carry = U32Shr(low, 32 - bits);
  this.value[0] = U32Shl(low, bits);
  this.value[1] = U32Shl(high, bits) + carry;
}

Num.prototype.Lt = function(num) {
  var high1 = this.High();
  var high2 = num.High();
  return high1 < high2 || high1 == high2 && this.Low() < num.Low();
}

Num.prototype.Equals = function(num) {
  return this.value[0] == num.value[0] && this.value[1] == num.value[1];
}

Num.prototype.NotEquals = function(num) {
  return this.value[0] != num.value[0] || this.value[1] != num.value[1];
}

Num.prototype.AlignDown = function(alignment) {
  this.value[0] = AlignDown(this.value[0], alignment);
}

Num.prototype.AlignUp = function(alignment) {
  this.Add(Num(alignment - 1));
  this.AlignDown(alignment);
}

Num.prototype.toString = function() {
  result = U32ToString(this.value[0]);
  if (this.value[1])
    result = U32ToString(this.value[1]) + result;
  return '0x' + result;
}

function RandomString() {
  return Math.random().toString(36).substring(7);
}

