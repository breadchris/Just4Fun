function Platform() {
  this.platform = window.navigator.platform;
  this.user_agent = window.navigator.userAgent;
}

Platform.prototype.PlatformContains = function(key) {
  return this.platform.indexOf(key) != -1;
}

Platform.prototype.UserAgentContains = function(key) {
  return this.user_agent.indexOf(key) != -1;
}

Platform.prototype.Is32BitBrowser = function() {
  return this.PlatformContains('32');
}

Platform.prototype.Is64BitBrowser = function() {
  return this.PlatformContains('64');
}

Platform.prototype.IsWindows = function() {
  return this.PlatformContains('Win');
}

Platform.prototype.IsLinux = function() {
  return this.PlatformContains('Linux');
}

Platform.prototype.IsFirefox = function() {
  return this.UserAgentContains('Firefox');
}

Platform.prototype.BrowserVersion = function() {
  if (this.IsFirefox()) {
    agent = this.user_agent;
    version_string = agent.substring(agent.indexOf('Firefox') + 8);
    version = parseInt(version_string, 10);
    return isNaN(version) ? -1 : version;
  }
  return -1;
}

