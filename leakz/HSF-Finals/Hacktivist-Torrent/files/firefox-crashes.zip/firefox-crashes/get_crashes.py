import os, shutil, re
from pyquery import PyQuery as pq
from lxml import etree
import requests

import sys
reload(sys)
sys.setdefaultencoding('UTF8')

base_dir = ""
known_vulns = "https://www.mozilla.org/en-US/security/known-vulnerabilities/firefox/"
base_url = "https://www.mozilla.org"
base_bug = "https://bugzilla.mozilla.org/"
cve_re = re.compile("^CVE\-\d{4}\-\d{4}")

def mkdir(path):
    if not os.path.isdir(path):
        os.mkdir(path)

def get_vulns():
    html = pq(url=known_vulns)
    vuln_links = html(".level-item").find("a")[::-1]
    for v in vuln_links:
        folder = v.getchildren()[0].text
        level = v.getchildren()[0].attrib['class'].split(" ")[1]
        if level != "critical":
            continue
        if "href" in v.attrib:
            desc = v.text_content().strip()
            yield folder, desc, v.attrib["href"]

def get_bugs():
    for folder, desc, vuln in get_vulns():
        mkdir(base_dir + folder)
        with open(base_dir + folder + "/README", "w") as f:
            f.write(desc + "\n")
        cve_html = pq(url=base_url + vuln)
        refs = cve_html("div[itemprop='articleBody'] a")
        with open(base_dir + folder + "/README", "a+") as f:
            about = refs.text().split(" ")
            for line in about:
                if "https://" in line or cve_re.match(line):
                    f.write(line + "\n")
        for ref in refs:
            if "href" in ref.attrib and "CVE" != ref.text[:3]:
                yield folder, ref.attrib["href"]

def get_pocs():
    for folder, bug in get_bugs():
        try:
            bug_html = pq(url=bug)
        except:
            continue
        attachments = bug_html("tr").filter(".bz_contenttype_text_html")
        for n, attach in enumerate(attachments):
            td = attach.getchildren()[0]
            a = td.getchildren()[0]
            url = base_bug + a.get("href")
            r = requests.get(url)
            with open(base_dir + folder + "/crash_%d.html" % n, 'w') as f:
                f.write(r.text)
                print "[+] Added:", folder
        js_things = bug_html("tr").filter(".bz_contenttype_application_x-javascript")
        for n, js in enumerate(js_things):
            td = js.getchildren()[0]
            a = td.getchildren()[0]
            url = base_bug + a.get("href")
            r = requests.get(url)
            with open(base_dir + folder + "/crash_%d.js" % n, 'w') as f:
                f.write(r.text)
                print "[+] Added:", folder

if base_dir:
    mkdir(base_dir)
get_pocs()
